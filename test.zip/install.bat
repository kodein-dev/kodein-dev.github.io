@echo off
chcp 65001 >nul
echo  Library downloader
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] PYTHON NOT FOUND
    pause
    exit /b 1
)

echo [1/3] Update pip...
python -m pip install --upgrade pip

echo.
echo [2/3] Dowload library...
pip install pyTelegramBotAPI Pillow psutil requests[socks] sounddevice soundfile scipy pycaw comtypes opencv-python numpy

echo.
echo [3/3] Download other...
pip install nuitka zstandard ordered-set

echo.
echo  succesfully! close this window
pause
